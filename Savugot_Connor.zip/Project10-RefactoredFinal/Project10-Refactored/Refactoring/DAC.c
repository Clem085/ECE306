/* DAC Program Information
-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
  File Name : DAC.c
  Description:  This file contains the code to control the DAC (Digital to Analog Converter)
  Programmer: Connor Savugot
  Date Created: Nov 8, 2024
-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
*/

// #include as of 11-27-24
//// Header Files
#include  "ADC.h"
#include  "DAC.h"
#include  "Display.h"
#include  "functions.h"
#include  "interrupts.h"
#include  "IR.h"
#include  "IOT.h"
#include  "LCD.h"
#include  "macros.h"
#include  "menu.h"
#include  "motors.h"
#include  "msp430.h"
#include  "ports.h"
#include  "serial.h"
#include  "switches.h"
#include  "timers.h"
//// Libraries
#include  <stdio.h>
#include  <string.h>


// Global Variables declared and referenced in Header file



//------------------------------------------------------------------------------
//  MSP430FR235x Demo - SAC-L3, DAC Buffer Mode
//
//  Description: Configure SAC-L3 for DAC Buffer Mode. Use the 12 bit DAC to
//  output positive ramp. The OA is set in buffer mode to improve DAC output
//  drive strength. Internal 2.5V reference is selected as DAC reference.
//  Observe the output of OA0O pin with oscilloscope.
//  ACLK = n/a, MCLK = SMCLK = default DCODIV ~1MHz.
//
//                MSP430FR235x
//             -------------------
//         /|\|                   |
//          | |                   |
//          --|RST     DAC12->OA0O|--> oscilloscope
//            |                   |
//            |                   |
//------------------------------------------------------------------------------
void Init_DAC(void){
    DAC_data = 4000;
    SAC3DAT  = DAC_data;                  // Initial DAC data
    SAC3DAC  = DACSREF_0;                 // Select AVCC as DAC reference
    SAC3DAC |= DACLSEL_0;                 // DAC latch loads when DACDAT written

    SAC3OA   = NMUXEN;                    // SAC Negative input MUX controL
    SAC3OA  |= PMUXEN;                    // SAC Positive input MUX control
    SAC3OA  |= PSEL_1;                    // 12-bit reference DAC source selected
    SAC3OA  |= NSEL_1;                    // Select negative pin input
    SAC3OA  |= OAPM;                      // Select low speed and low power mode
    SAC3PGA  = MSEL_1;                    // Set OA as buffer mode
    SAC3OA  |= SACEN;                     // Enable SAC
    SAC3OA  |= OAEN;                      // Enable OA

    P3OUT   &= ~DAC_CTRL;                 // Set output to Low
    P3DIR   &= ~DAC_CTRL;                 // Set direction to input
    P3SELC  |=  DAC_CTRL;                 // DAC_CTRL DAC operation
    SAC3DAC |=  DACEN;                    // Enable DAC

}

// DAC Interrupt moved to interrupts.c


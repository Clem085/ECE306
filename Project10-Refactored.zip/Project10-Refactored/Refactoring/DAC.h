//===========================================================================
//  File Name: DAC.h
//  Description: Header file for DAC.c - Contains Globals, Macros, & function declarations
//  Author: Connor Savugot
//  Date: Nov 8, 2024
//===========================================================================

#ifndef DAC_H_
#define DAC_H_


// Global Variables
//// Internally Defined
unsigned int DAC_data;
//// Externally Defined



// Macro Definitions



// Function Declarations
void Init_DAC(void);





#endif /* DAC_H_ */

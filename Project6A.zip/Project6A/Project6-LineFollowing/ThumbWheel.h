/*
 * ThumbWhell.h
 *
 *  Created on: Oct 14, 2024
 *      Author: jammi
 */

#ifndef THUMBWHEEL_H_
#define THUMBWHEEL_H_


void HexToBCD(int);


#endif /* THUMBWHEEL_H_ */

/*
 * ADC.h
 *
 *  Created on: Oct 14, 2024
 *      Author: jammi
 */

#ifndef ADC_H_
#define ADC_H_

void Init_ADC(void);



#endif /* ADC_H_ */

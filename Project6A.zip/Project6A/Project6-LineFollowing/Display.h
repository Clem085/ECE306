#ifndef DISPLAY_H_
#define DISPLAY_H_

void backlight_control(void);
//void dispPrint(char *, char *, char *, char *);
void dispPrint(char *line, char lineToUpdate);
int middleChar(char * string);
void adc_line(char line, char location);
#endif /* DISPLAY_H_ */
